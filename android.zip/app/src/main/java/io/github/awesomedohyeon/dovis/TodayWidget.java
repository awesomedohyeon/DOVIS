package io.github.awesomedohyeon.dovis;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

/** 오늘 요약 위젯: 한 줄 요약, 오늘 흐름, 다음 일정, 주의할 점, 할 일 */
public class TodayWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) mgr.updateAppWidget(id, build(ctx));
    }

    static void updateAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, TodayWidget.class));
        if (ids == null || ids.length == 0) return;
        RemoteViews v = build(ctx);
        for (int id : ids) mgr.updateAppWidget(id, v);
    }

    static RemoteViews build(Context ctx) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_today);
        Intent open = new Intent(ctx, MainActivity.class);
        open.putExtra("tab", "today");
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(ctx, 21, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        JSONObject day = null;
        try {
            String json = Store.get(ctx, "widgets");
            if (json != null) {
                JSONObject w = new JSONObject(json);
                String today = Store.today();
                JSONArray days = w.optJSONArray("todays");
                if (days != null) {
                    for (int i = 0; i < days.length(); i++) {
                        JSONObject d = days.getJSONObject(i);
                        if (today.equals(d.optString("date"))) { day = d; break; }
                    }
                }
            }
        } catch (Exception ignored) {}

        if (day == null) {
            v.setTextViewText(R.id.label, "DOVIS");
            v.setTextViewText(R.id.headline, "DOVIS를 한 번 열어줘");
            v.setTextViewText(R.id.flow, "앱을 열면 오늘 내용으로 바뀌어");
            v.setViewVisibility(R.id.next, View.GONE);
            v.setViewVisibility(R.id.warn, View.GONE);
            v.setViewVisibility(R.id.todos, View.GONE);
            return v;
        }
        v.setTextViewText(R.id.label, "DOVIS · " + day.optString("label"));
        v.setTextViewText(R.id.headline, day.optString("headline"));
        v.setTextViewText(R.id.flow, day.optString("flow"));
        String next = day.optString("next");
        v.setViewVisibility(R.id.next, next.isEmpty() ? View.GONE : View.VISIBLE);
        v.setTextViewText(R.id.next, "다음: " + next);
        String warn = day.optString("warn");
        v.setViewVisibility(R.id.warn, warn.isEmpty() ? View.GONE : View.VISIBLE);
        v.setTextViewText(R.id.warn, "⚠ " + warn);
        JSONArray todos = day.optJSONArray("todos");
        int cnt = day.optInt("todoCount");
        if (todos != null && todos.length() > 0) {
            StringBuilder sb = new StringBuilder("할 일 " + cnt + "개 · ");
            for (int i = 0; i < todos.length(); i++) { if (i > 0) sb.append(", "); sb.append(todos.optString(i)); }
            v.setTextViewText(R.id.todos, sb.toString());
            v.setViewVisibility(R.id.todos, View.VISIBLE);
        } else v.setViewVisibility(R.id.todos, View.GONE);
        return v;
    }
}
