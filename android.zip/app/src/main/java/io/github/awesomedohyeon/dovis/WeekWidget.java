package io.github.awesomedohyeon.dovis;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

/** 주간 달력 위젯: 일~토 7칸에 일정 블록을 그림 */
public class WeekWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) mgr.updateAppWidget(id, build(ctx, mgr, id));
    }

    @Override
    public void onAppWidgetOptionsChanged(Context ctx, AppWidgetManager mgr, int id, Bundle opts) {
        mgr.updateAppWidget(id, build(ctx, mgr, id));
    }

    static void updateAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, WeekWidget.class));
        if (ids == null) return;
        for (int id : ids) mgr.updateAppWidget(id, build(ctx, mgr, id));
    }

    static RemoteViews build(Context ctx, AppWidgetManager mgr, int id) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_week);
        Intent open = new Intent(ctx, MainActivity.class);
        open.putExtra("tab", "week");
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(ctx, 22, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        float dens = ctx.getResources().getDisplayMetrics().density;
        Bundle o = mgr.getAppWidgetOptions(id);
        int wDp = o != null ? o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 300) : 300;
        int hDp = o != null ? o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 220) : 220;
        if (wDp < 150) wDp = 300;
        if (hDp < 100) hDp = 220;
        float scale = Math.min(dens, 1100f / wDp);
        int W = Math.round(wDp * scale), H = Math.round(hDp * scale);
        v.setImageViewBitmap(R.id.week_img, draw(ctx, W, H, scale));
        return v;
    }

    private static int parseColor(String c, int fallback) {
        try { return Color.parseColor(c); } catch (Exception e) { return fallback; }
    }

    static Bitmap draw(Context ctx, int W, int H, float dp) {
        Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int blue = 0xFF3B5BDB, text = 0xFF17181A, sub = 0xFF8A8F98, line = 0xFFEDEFF2;

        JSONObject week = null;
        try {
            String json = Store.get(ctx, "widgets");
            if (json != null) week = new JSONObject(json).optJSONObject("week");
        } catch (Exception ignored) {}

        float pad = 12 * dp;
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(13 * dp);
        p.setColor(text);
        if (week == null) {
            cv.drawText("DOVIS를 한 번 열어줘", pad, pad + 14 * dp, p);
            return bmp;
        }
        String today = Store.today();
        JSONArray days = week.optJSONArray("days");
        if (days == null || days.length() < 7) return bmp;
        boolean inWeek = false;
        for (int i = 0; i < 7; i++) if (today.equals(days.optJSONObject(i).optString("date"))) inWeek = true;
        int accent = parseColor(week.optString("accent"), blue);

        cv.drawText("DOVIS · " + week.optString("title"), pad, pad + 12 * dp, p);
        if (!inWeek) {
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(11 * dp);
            p.setColor(sub);
            cv.drawText("앱을 열면 새 주간으로 바뀌어", pad, pad + 30 * dp, p);
        }

        float axis = 20 * dp;
        float left = pad + axis, right = W - pad;
        float colW = (right - left) / 7f;
        float headTop = pad + 20 * dp, headH = 30 * dp;
        float gridTop = headTop + headH + 4 * dp, gridBot = H - pad;

        // 시간 범위
        int minH = 9, maxH = 21;
        for (int i = 0; i < 7; i++) {
            JSONArray it = days.optJSONObject(i).optJSONArray("items");
            if (it == null) continue;
            for (int k = 0; k < it.length(); k++) {
                JSONObject e = it.optJSONObject(k);
                minH = Math.min(minH, e.optInt("s") / 60);
                maxH = Math.max(maxH, (e.optInt("e") + 59) / 60);
            }
        }
        minH = Math.max(6, minH);
        maxH = Math.min(24, Math.max(maxH, minH + 4));
        float hourH = (gridBot - gridTop) / (maxH - minH);

        // 요일 머리
        for (int i = 0; i < 7; i++) {
            JSONObject d = days.optJSONObject(i);
            float cx = left + colW * i + colW / 2f;
            boolean isT = today.equals(d.optString("date"));
            p.setTypeface(Typeface.DEFAULT);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(9.5f * dp);
            p.setColor(isT ? accent : (i == 0 ? 0xFFE03131 : sub));
            cv.drawText(d.optString("dow"), cx, headTop + 9 * dp, p);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(12 * dp);
            if (isT) {
                p.setColor(accent);
                cv.drawCircle(cx, headTop + 20 * dp, 10 * dp, p);
                p.setColor(Color.WHITE);
            } else p.setColor(text);
            cv.drawText(String.valueOf(d.optInt("day")), cx, headTop + 24.5f * dp, p);
        }
        p.setTextAlign(Paint.Align.LEFT);

        // 시간 줄
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(8 * dp);
        for (int h = minH; h <= maxH; h += 2) {
            float y = gridTop + (h - minH) * hourH;
            p.setColor(line);
            p.setStrokeWidth(1);
            cv.drawLine(left, y, right, y, p);
            p.setColor(sub);
            cv.drawText(String.valueOf(h), pad, y + 3 * dp, p);
        }

        // 일정 블록
        for (int i = 0; i < 7; i++) {
            JSONObject d = days.optJSONObject(i);
            JSONArray it = d.optJSONArray("items");
            if (it == null) continue;
            float x0 = left + colW * i + 1.5f * dp, x1 = left + colW * (i + 1) - 1.5f * dp;
            for (int k = 0; k < it.length(); k++) {
                JSONObject e = it.optJSONObject(k);
                float y0 = gridTop + (e.optInt("s") / 60f - minH) * hourH;
                float y1 = gridTop + (e.optInt("e") / 60f - minH) * hourH;
                if (y1 - y0 < 6 * dp) y1 = y0 + 6 * dp;
                RectF r = new RectF(x0, y0 + 0.5f * dp, x1, y1 - 0.5f * dp);
                int col = parseColor(e.optString("c"), accent);
                boolean task = e.optInt("task") == 1;
                p.setStyle(Paint.Style.FILL);
                p.setColor(task ? Color.WHITE : col);
                cv.drawRoundRect(r, 4 * dp, 4 * dp, p);
                if (task) {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(1.2f * dp);
                    p.setColor(col);
                    cv.drawRoundRect(r, 4 * dp, 4 * dp, p);
                    p.setStyle(Paint.Style.FILL);
                }
                if (r.height() >= 11 * dp) {
                    cv.save();
                    cv.clipRect(r);
                    p.setTypeface(Typeface.DEFAULT_BOLD);
                    p.setTextSize(8.5f * dp);
                    p.setColor(task ? text : Color.WHITE);
                    String t = e.optString("t");
                    if (e.optInt("done") == 1) t = "✓" + t;
                    cv.drawText(t, r.left + 2.5f * dp, r.top + 9 * dp, p);
                    cv.restore();
                }
            }
        }

        // 지금 시각 선
        if (inWeek) {
            java.util.Calendar now = java.util.Calendar.getInstance();
            float hh = now.get(java.util.Calendar.HOUR_OF_DAY) + now.get(java.util.Calendar.MINUTE) / 60f;
            if (hh >= minH && hh <= maxH) {
                for (int i = 0; i < 7; i++) {
                    if (!today.equals(days.optJSONObject(i).optString("date"))) continue;
                    float y = gridTop + (hh - minH) * hourH;
                    p.setColor(0xFFE03131);
                    p.setStrokeWidth(1.5f * dp);
                    cv.drawLine(left + colW * i, y, left + colW * (i + 1), y, p);
                }
            }
        }
        return bmp;
    }
}
