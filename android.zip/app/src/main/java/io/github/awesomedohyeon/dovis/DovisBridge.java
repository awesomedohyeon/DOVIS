package io.github.awesomedohyeon.dovis;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;

/** DOVIS 웹 ↔ 안드로이드 연결 (window.DovisNative) */
public class DovisBridge {
    private final MainActivity act;

    DovisBridge(MainActivity act) { this.act = act; }

    @JavascriptInterface
    public String isApp() { return "1"; }

    @JavascriptInterface
    public String appVersion() {
        try { return act.getPackageManager().getPackageInfo(act.getPackageName(), 0).versionName; }
        catch (Exception e) { return ""; }
    }

    /** 홈 화면에 위젯 바로 추가하기 (폰이 지원하면 "추가할까요?" 창이 뜸) */
    @JavascriptInterface
    public String pinWidget(String kind) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(act);
            if (!mgr.isRequestPinAppWidgetSupported()) return "0";
            Class<?> cls = "week".equals(kind) ? WeekWidget.class : "command".equals(kind) ? CommandWidget.class : TodayWidget.class;
            return mgr.requestPinAppWidget(new ComponentName(act, cls), null, null) ? "1" : "0";
        } catch (Exception e) {
            return "0";
        }
    }

    @JavascriptInterface
    public void setWidgets(String json) {
        Store.put(act, "widgets", json);
        TodayWidget.updateAll(act);
        WeekWidget.updateAll(act);
    }

    @JavascriptInterface
    public void setAlarms(String json) {
        Store.put(act, "alarms", json);
        Alarms.schedule(act);
    }

    @JavascriptInterface
    public void requestNotifications() { act.askNotifications(); }

    @JavascriptInterface
    public String hasCalendarPermission() { return act.hasCalendar() ? "1" : "0"; }

    @JavascriptInterface
    public void requestCalendar() { act.askCalendar(); }

    @JavascriptInterface
    public void googleSignIn(String webClientId) { act.googleSignIn(webClientId); }

    /** 폰 캘린더(삼성·구글)에서 일정 읽기 */
    @JavascriptInterface
    public String readCalendar(String fromMs, String toMs) {
        JSONArray out = new JSONArray();
        if (!act.hasCalendar()) return out.toString();
        Cursor c = null;
        try {
            Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
            ContentUris.appendId(b, Long.parseLong(fromMs));
            ContentUris.appendId(b, Long.parseLong(toMs));
            String[] proj = {
                    CalendarContract.Instances.EVENT_ID,
                    CalendarContract.Instances.TITLE,
                    CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.END,
                    CalendarContract.Instances.ALL_DAY,
                    CalendarContract.Instances.DESCRIPTION,
                    CalendarContract.Instances.RRULE
            };
            c = act.getContentResolver().query(b.build(), proj, CalendarContract.Instances.VISIBLE + "=1", null,
                    CalendarContract.Instances.BEGIN + " ASC");
            SimpleDateFormat local = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            SimpleDateFormat utcDay = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            utcDay.setTimeZone(TimeZone.getTimeZone("UTC"));
            while (c != null && c.moveToNext()) {
                String desc = c.isNull(5) ? "" : c.getString(5);
                if (desc.startsWith("[DOVIS]")) continue;
                long begin = c.getLong(2), end = c.getLong(3);
                boolean allDay = c.getInt(4) == 1;
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(0) + "_" + begin);
                o.put("title", c.isNull(1) ? "(제목 없음)" : c.getString(1));
                o.put("allDay", allDay);
                o.put("desc", desc);
                o.put("recurring", !c.isNull(6) && !c.getString(6).isEmpty());
                if (allDay) {
                    o.put("startDate", utcDay.format(begin));
                    o.put("endDate", utcDay.format(end));
                } else {
                    o.put("start", local.format(begin));
                    o.put("end", local.format(end));
                }
                out.put(o);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return out.toString();
    }

    /** DOVIS의 특별한 일정을 폰 캘린더(구글 계정)에 넣거나 고치기 → 구글 캘린더로 동기화됨 */
    @JavascriptInterface
    public String upsertEvent(String json) {
        if (!act.hasCalendar()) return "";
        try {
            JSONObject e = new JSONObject(json);
            long calId = findCalendar();
            if (calId < 0) return "";
            ContentValues v = new ContentValues();
            v.put(CalendarContract.Events.TITLE, e.optString("title"));
            v.put(CalendarContract.Events.DESCRIPTION, e.optString("desc"));
            v.put(CalendarContract.Events.EVENT_LOCATION, e.optString("location"));
            boolean allDay = e.optBoolean("allDay");
            if (allDay) {
                SimpleDateFormat utcDay = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                utcDay.setTimeZone(TimeZone.getTimeZone("UTC"));
                long s = utcDay.parse(e.optString("startDate")).getTime();
                long en = utcDay.parse(e.optString("endDate")).getTime();
                if (en <= s) en = s + 86400000L;
                v.put(CalendarContract.Events.DTSTART, s);
                v.put(CalendarContract.Events.DTEND, en);
                v.put(CalendarContract.Events.EVENT_TIMEZONE, "UTC");
                v.put(CalendarContract.Events.ALL_DAY, 1);
            } else {
                v.put(CalendarContract.Events.DTSTART, e.optLong("startMs"));
                v.put(CalendarContract.Events.DTEND, e.optLong("endMs"));
                v.put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());
                v.put(CalendarContract.Events.ALL_DAY, 0);
            }
            ContentResolver cr = act.getContentResolver();
            String id = e.optString("id", "");
            if (!id.isEmpty()) {
                int n = cr.update(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, Long.parseLong(id)), v, null, null);
                if (n > 0) return id;
            }
            v.put(CalendarContract.Events.CALENDAR_ID, calId);
            Uri u = cr.insert(CalendarContract.Events.CONTENT_URI, v);
            return u != null ? u.getLastPathSegment() : "";
        } catch (Exception ex) {
            return "";
        }
    }

    @JavascriptInterface
    public String deleteEvent(String id) {
        if (!act.hasCalendar()) return "0";
        try {
            int n = act.getContentResolver().delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, Long.parseLong(id)), null, null);
            return n > 0 ? "1" : "0";
        } catch (Exception e) {
            return "0";
        }
    }

    /** 일정을 넣을 캘린더: 구글 계정 기본 캘린더 → 구글 계정 아무거나 → 쓸 수 있는 아무거나 */
    private long findCalendar() {
        long best = -1;
        int bestScore = -1;
        String[] proj = {
                CalendarContract.Calendars._ID,
                CalendarContract.Calendars.ACCOUNT_TYPE,
                CalendarContract.Calendars.IS_PRIMARY,
                CalendarContract.Calendars.VISIBLE
        };
        try (Cursor c = act.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI, proj,
                CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + ">=" + CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR, null, null)) {
            while (c != null && c.moveToNext()) {
                int score = 0;
                if ("com.google".equals(c.getString(1))) score += 4;
                if (!c.isNull(2) && c.getInt(2) == 1) score += 2;
                if (c.getInt(3) == 1) score += 1;
                if (score > bestScore) { bestScore = score; best = c.getLong(0); }
            }
        } catch (Exception ignored) {}
        return best;
    }
}
