package io.github.awesomedohyeon.dovis;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** 아침 알림 띄우기 */
public class AlarmReceiver extends BroadcastReceiver {
    static final String CHANNEL = "morning";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "아침 요약", NotificationManager.IMPORTANCE_DEFAULT));
        String title = intent.getStringExtra("title");
        String text = intent.getStringExtra("text");
        Intent open = new Intent(ctx, MainActivity.class);
        open.putExtra("tab", "today");
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_logo_white)
                .setColor(0xFF3B5BDB)
                .setContentTitle(title != null ? title : "DOVIS")
                .setContentText(text != null ? text : "")
                .setStyle(new Notification.BigTextStyle().bigText(text != null ? text : ""))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        nm.notify(intent.getIntExtra("id", 1000), n);
    }
}
