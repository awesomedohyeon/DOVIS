package io.github.awesomedohyeon.dovis;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 앱(웹)이 보내준 위젯·알림 데이터를 저장해두는 곳 */
final class Store {
    private Store() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("dovis", Context.MODE_PRIVATE);
    }

    static void put(Context c, String key, String value) {
        prefs(c).edit().putString(key, value).apply();
    }

    static String get(Context c, String key) {
        return prefs(c).getString(key, null);
    }

    static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }
}
