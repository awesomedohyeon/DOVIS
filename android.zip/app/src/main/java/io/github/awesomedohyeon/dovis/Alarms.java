package io.github.awesomedohyeon.dovis;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

/** 아침 기상 알림 예약 (앞으로 7일) */
final class Alarms {
    private Alarms() {}
    private static final int BASE = 1000;
    private static final int MAX = 8;

    static void schedule(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int i = 0; i < MAX; i++) {
            PendingIntent old = PendingIntent.getBroadcast(ctx, BASE + i, new Intent(ctx, AlarmReceiver.class),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (old != null) { am.cancel(old); old.cancel(); }
        }
        String json = Store.get(ctx, "alarms");
        if (json == null) return;
        try {
            JSONArray arr = new JSONArray(json);
            long now = System.currentTimeMillis();
            int slot = 0;
            for (int i = 0; i < arr.length() && slot < MAX; i++) {
                JSONObject a = arr.getJSONObject(i);
                long at = a.optLong("at");
                if (at <= now) continue;
                Intent it = new Intent(ctx, AlarmReceiver.class);
                it.putExtra("title", a.optString("title"));
                it.putExtra("text", a.optString("text"));
                it.putExtra("id", BASE + slot);
                PendingIntent pi = PendingIntent.getBroadcast(ctx, BASE + slot, it,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                slot++;
            }
        } catch (Exception ignored) {}
    }
}
