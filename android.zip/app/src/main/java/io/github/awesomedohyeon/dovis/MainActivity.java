package io.github.awesomedohyeon.dovis;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;

import org.json.JSONObject;

import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    static final String APP_URL = "https://awesomedohyeon.github.io/DOVIS/";
    static final String APP_HOST = "awesomedohyeon.github.io";
    private static final int REQ_CALENDAR = 11;
    private static final int REQ_NOTIF = 12;
    private static final String GOOGLE_ID_TYPE = "com.google.android.libraries.identity.googleid.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL";
    private static final String GOOGLE_ID_KEY = "com.google.android.libraries.identity.googleid.BUNDLE_KEY_ID_TOKEN";

    WebView web;
    private boolean loaded = false;
    private String pendingTab = null;
    private final Handler main = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFF3B5BDB);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);

        web.addJavascriptInterface(new DovisBridge(this), "DovisNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u != null && APP_HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                loaded = true;
                if (pendingTab != null) { sendEvent("open", pendingTab); pendingTab = null; }
            }
        });

        pendingTab = getIntent() != null ? getIntent().getStringExtra("tab") : null;
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(APP_URL);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String tab = intent.getStringExtra("tab");
        if (tab != null) {
            if (loaded) sendEvent("open", tab); else pendingTab = tab;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (loaded) sendEvent("resume", "");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    /** 웹(DOVIS)에 이벤트 알려주기 */
    void sendEvent(String type, String data) {
        final String js = "window.dovisNativeEvent&&window.dovisNativeEvent(" + JSONObject.quote(type) + "," + JSONObject.quote(data == null ? "" : data) + ")";
        main.post(() -> web.evaluateJavascript(js, null));
    }

    boolean hasCalendar() {
        return checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED;
    }

    void askCalendar() {
        main.post(() -> {
            if (hasCalendar()) { sendEvent("calendarPermission", "1"); return; }
            requestPermissions(new String[]{Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR}, REQ_CALENDAR);
        });
    }

    void askNotifications() {
        if (Build.VERSION.SDK_INT < 33) return;
        main.post(() -> {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CALENDAR) sendEvent("calendarPermission", hasCalendar() ? "1" : "0");
    }

    /** 구글 로그인 (Credential Manager) → ID 토큰을 웹으로 전달 */
    void googleSignIn(String webClientId) {
        main.post(() -> {
            try {
                CredentialManager cm = CredentialManager.create(this);
                GetGoogleIdOption option = new GetGoogleIdOption.Builder()
                        .setFilterByAuthorizedAccounts(false)
                        .setServerClientId(webClientId)
                        .build();
                GetCredentialRequest request = new GetCredentialRequest.Builder()
                        .addCredentialOption(option)
                        .build();
                Executor ex = main::post;
                cm.getCredentialAsync(this, request, new CancellationSignal(), ex,
                        new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                            @Override
                            public void onResult(GetCredentialResponse result) {
                                Credential c = result.getCredential();
                                if (c instanceof CustomCredential && GOOGLE_ID_TYPE.equals(c.getType())) {
                                    String token = c.getData().getString(GOOGLE_ID_KEY);
                                    sendEvent("signIn", token != null ? token : "error:토큰 없음");
                                } else {
                                    sendEvent("signIn", "error:구글 계정이 아니야");
                                }
                            }

                            @Override
                            public void onError(GetCredentialException e) {
                                sendEvent("signIn", "error:" + e.getMessage());
                            }
                        });
            } catch (Exception e) {
                sendEvent("signIn", "error:" + e.getMessage());
            }
        });
    }
}
