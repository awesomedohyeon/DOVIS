package io.github.awesomedohyeon.dovis;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 위젯에서 뜨는 작은 입력창. 보내면 DOVIS 앱이 열리면서 바로 처리 */
public class QuickInputActivity extends Activity {
    private EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        float d = getResources().getDisplayMetrics().density;
        int pad = Math.round(16 * d);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("DOVIS에게 말하기");
        title.setTextSize(16);
        title.setTextColor(0xFF17181A);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        box.addView(title);

        input = new EditText(this);
        input.setHint("예) 내일 7시 동집 약속");
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) { send(); return true; }
            return false;
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Math.round(8 * d);
        box.addView(input, lp);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.END);
        Button cancel = new Button(this, null, android.R.attr.borderlessButtonStyle);
        cancel.setText("닫기");
        cancel.setOnClickListener(v -> finish());
        Button ok = new Button(this, null, android.R.attr.borderlessButtonStyle);
        ok.setText("보내기");
        ok.setTextColor(0xFF3B5BDB);
        ok.setOnClickListener(v -> send());
        row.addView(cancel);
        row.addView(ok);
        box.addView(row);

        setContentView(box);
        getWindow().setLayout(Math.round(getResources().getDisplayMetrics().widthPixels * 0.9f), WindowManager.LayoutParams.WRAP_CONTENT);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        input.requestFocus();
    }

    private void send() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        Intent it = new Intent(this, MainActivity.class);
        it.putExtra("say", text);
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(it);
        finish();
    }
}
