package io.github.awesomedohyeon.dovis;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 위젯에서 뜨는 입력창: 화면 아래쪽, 키보드 바로 위에 붙는 카드 */
public class QuickInputActivity extends Activity {
    private EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quick_input);
        float d = getResources().getDisplayMetrics().density;

        Window w = getWindow();
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.gravity = Gravity.BOTTOM;
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.y = Math.round(10 * d);
        w.setAttributes(lp);
        w.getDecorView().setPadding(Math.round(10 * d), 0, Math.round(10 * d), 0);
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        input = findViewById(R.id.input);
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) { send(input.getText().toString()); return true; }
            return false;
        });
        findViewById(R.id.send).setOnClickListener(v -> send(input.getText().toString()));
        findViewById(R.id.close).setOnClickListener(v -> finish());

        LinearLayout chips = findViewById(R.id.chips);
        String[] quick = {"오늘 남은 일정", "이번 주 빈 시간", "할 일 추가하기", "내일 일정"};
        for (String q : quick) {
            TextView c = new TextView(this);
            c.setText(q);
            c.setTextSize(13);
            c.setTextColor(0xFF3B5BDB);
            c.setBackgroundResource(R.drawable.quick_chip_bg);
            c.setPadding(Math.round(12 * d), Math.round(7 * d), Math.round(12 * d), Math.round(7 * d));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            p.rightMargin = Math.round(6 * d);
            c.setOnClickListener(v -> {
                if (q.equals("할 일 추가하기")) { input.setText(""); input.setHint("예) 분석학 실험 4강 듣기, 목요일까지"); input.requestFocus(); }
                else send(q);
            });
            chips.addView(c, p);
        }
        input.requestFocus();
    }

    private void send(String raw) {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) return;
        Intent it = new Intent(this, MainActivity.class);
        it.putExtra("say", text);
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(it);
        finish();
    }
}
