package io.github.awesomedohyeon.dovis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** 폰을 껐다 켜거나 앱이 업데이트되면 알림·위젯 다시 맞추기 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        Alarms.schedule(ctx);
        TodayWidget.updateAll(ctx);
        WeekWidget.updateAll(ctx);
    }
}
